package main;

import model.Faculty;
import model.Staff;
public class EmployeeTest {
	
	public static void main(String[]args) {
		Faculty f1= new Faculty();
		Faculty f2= new Faculty("Ahmed"	,10000,"Lecturer","Engineering");
		
		Staff s1= new Staff();
		Staff s2= new Staff("Ali",8000,"Research","Research Assistant");
		
		System.out.println(f1);
		System.out.println("-------------------");
		System.out.println(f2);
		System.out.println("-------------------");
		System.out.println(s1);
		System.out.println("-------------------");
		System.out.println(s2);
	}

}
