package model;
import java.util.ArrayList; 
public class Department {
	 private int deptNo; 
	    private String title; 
	    private ArrayList<Employee> employees = new ArrayList<>(); 
	  
	    public Department(int deptNo, String title) { 
	        super(); 
	        this.deptNo = deptNo; 
	        this.title = title; 
	    } 
	  
	    public boolean addEmployee(Employee e) { 
	        return employees.add(e); 
	    } 
	  
	    public boolean removeEmployee(Employee e) { 
	        return employees.remove(e); 
	    } 
	  
	    public int getDeptNo() { 
	        return deptNo; 
	    } 
	  
	    public void setDeptNo(int deptNo) { 
	        this.deptNo = deptNo; 
	    } 
	  
	    public String getTitle() { 
	        return title; 
	    } 
	  
	    public void setTitle(String title) { 
	        this.title = title; 
	    } 
	  
	    public ArrayList<Employee> getEmployees() { 
	        return employees;
	        }

	    public void setEmployees(ArrayList<Employee> employees) { 
	        this.employees = employees; 
	    } 
}