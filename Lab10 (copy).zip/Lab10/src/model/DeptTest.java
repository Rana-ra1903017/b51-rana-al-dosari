package model;
import java.util.logging.Logger;
import java.util.ArrayList; 
public class DeptTest {
	private static final Logger LOGGER=Logger.getLogger(DeptTest.class.getName());
	public static void main(String[] args) { 
        ArrayList<Employee> emps = new ArrayList<>(); 
        
        emps.add(new Faculty("Ahmed", 12000, "Lecturer", "Engineering")); 
        emps.add(new Staff("Ali", 8000, "Research Assistant", "Engineering")); 
        emps.add(new Faculty("Bob", 10000, "Researcher", "Engineering")); 
  
        Department cse = new Department(1, "Computer Science & Engineering"); 
        StringBuilder formatted = new  StringBuilder();
        formatted.append(cse.getTitle()).append(" Department [").append(cse.getDeptNo()).append("]\n"); 
        cse.setEmployees(emps); 
  
        for (int i = 0; i < cse.getEmployees().size(); i++) 
            formatted.append("\t").append(i + 1).append(") ").append(cse.getEmployees().get(i)).append("\n"); 
        LOGGER.info(formatted.toString()); 
  
        double sum = 0; 
        for (Employee e : cse.getEmployees()) 
            sum += e.getSalary(); 
        double avg = sum / cse.getEmployees().size(); 
        LOGGER.info("Average Salary for CSE: }" + avg);
    } 

}
