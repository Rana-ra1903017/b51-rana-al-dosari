package model;

public class Faculty extends Employee {
	private String rank;
	private String collage;
	
	public Faculty() {}
	
	public Faculty(String name,double salary,String rank, String collage) {
		super(name,salary);
		this.rank = rank;
		this.collage = collage;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getCollage() {
		return collage;
	}

	public void setCollage(String collage) {
		this.collage = collage;
	}

	@Override
	public double calcNetSalary() {
		if (getSalary()==0)
		return 0;
		else
			return 1.15*getSalary()+500;	
	}

	@Override
	public String toString() {
		return super.toString()+" Faculty [rank=" + rank + ", collage=" + collage + "]";
	}
	
	
	

}
