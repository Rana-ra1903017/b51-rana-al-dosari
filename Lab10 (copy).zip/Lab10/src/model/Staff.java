package model;

public class Staff extends Employee {
	private String unitName;
	private String jobTitle;
	
	public Staff() {
	}

	public Staff(String name, double salary,String unitName,String jobTitle) {
		super(name, salary);
		this.unitName = unitName;
		this.jobTitle = jobTitle;
	}

	public String getUnitName() {
		return unitName;
	}

	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	
	@Override
	public double calcNetSalary() {
		if(getSalary()==0)
		  return 0;
		else
			return 1.1*getSalary();	
	}

	@Override
	public String toString() {
		return super.toString()+" Staff [unitName=" + unitName + ", jobTitle=" + jobTitle + "]";
	}
	

}
