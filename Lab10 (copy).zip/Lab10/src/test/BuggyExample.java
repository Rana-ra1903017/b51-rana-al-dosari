package test;

public class BuggyExample {

	    public static void main(String[] args) { 
	        BuggyExample example = new BuggyExample(); 
	  
	        // Example 1: Null pointer dereference 
	        String text = "welcome"; 
	        System.out.println(text.length()); // SpotBugs should warn about a possible NPE 
	  
	        // Example 2: Infinite loop / suspicious code 
	        int i = 0; 
	        while (i < 10) { 
	            System.out.println("Looping");
	            i++;
	        } 
	    } 
	} 


