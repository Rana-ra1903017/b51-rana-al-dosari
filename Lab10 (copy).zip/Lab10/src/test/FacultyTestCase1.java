package test;

import static org.junit.Assert.*;
import org.junit.Test;
import model.Faculty;

public class FacultyTestCase1 {
	Faculty f= new Faculty("Ahmed"	,10000,"lecturer","Engineering");

	@Test
	public void testCalcNetSalary() {
		assertEquals(12000.0,f.calcNetSalary(),0);
	}

	@Test
	public void testFacultyCounstructor() {
		testGetName();
		testGetSalary();
		testGetRank();
		testGetCollage();
	}

	@Test
	public void testGetRank() {
		assertEquals("lecturer",f.getRank());
	}

	@Test
	public void testGetCollage() {
		assertEquals("Engineering",f.getCollage());

	}

	@Test
	public void testGetName() {
		assertEquals("Ahmed",f.getName());
	}

	@Test
	public void testGetSalary() {
		assertEquals(10000,f.getSalary(),0);
	}

}
