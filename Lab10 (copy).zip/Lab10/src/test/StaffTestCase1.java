package test;

import static org.junit.Assert.*;
import org.junit.Test;
import model.Staff;

public class StaffTestCase1 {
	
	Staff s= new Staff("Ali",8000,"Research","Research Assistant");

	@Test
	public void testCalcNetSalary() {
		assertEquals(8800,s.calcNetSalary(),0);
	}

	@Test
	public void testStaffSConstracutor() {
		testGetJobTitle();
		testGetName();
		testGetSalary();
		testGetUnitName();
	}

	@Test
	public void testGetUnitName() {
		assertEquals("Research",s.getUnitName());
	}

	@Test
	public void testGetJobTitle() {
		assertEquals("Research Assistant",s.getJobTitle());
	}

	@Test
	public void testGetName() {
		assertEquals("Ali",s.getName());
	}

	@Test
	public void testGetSalary() {
		assertEquals(8000,s.getSalary(),0);
	}

}
