package test;

import static org.junit.Assert.*;
import org.junit.Test;
import model.Staff;

public class StaffTestCase2 {
	
	Staff s= new Staff();
	
	@Test
	public void testCalcNetSalary() {
		assertEquals(0,s.calcNetSalary(),0);
	}

	@Test
	public void testStaffStringDoubleStringString() {
		testGetJobTitle();
		testGetName();
		testGetSalary();
		testGetUnitName();
	}

	@Test
	public void testGetUnitName() {
		assertNull(s.getUnitName());
	}

	@Test
	public void testGetJobTitle() {
		assertNull(s.getJobTitle());
	}

	@Test
	public void testGetName() {
		assertNull(s.getName());
	}

	@Test
	public void testGetSalary() {
		assertEquals(0,s.getSalary(),0);
	}

}
