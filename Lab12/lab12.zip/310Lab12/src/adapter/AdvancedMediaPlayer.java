package adapter;

/** The incompatible interface (the adaptee interface). */
public interface AdvancedMediaPlayer {
    void playVLC(String fileName);
    void playMP4(String fileName);
}
