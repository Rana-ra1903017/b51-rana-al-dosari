package adapter;

/** Client class: plays mp3 itself and uses MediaAdapter for mp4 and vlc. */
public class AudioPlayer implements MediaPlayer {
    private MediaAdapter mediaAdapter;

    @Override
    public void play(String fileType, String fileName) {
        // built-in support for mp3
        if (fileType.equalsIgnoreCase("mp3")) {
            System.out.println("Playing mp3 file. Name: " + fileName);
        }
        // mediaAdapter provides support for the other formats
        else if (fileType.equalsIgnoreCase("vlc") || fileType.equalsIgnoreCase("mp4")) {
            mediaAdapter = new MediaAdapter(fileType);
            mediaAdapter.play(fileType, fileName);
        } else {
            System.out.println("Invalid media. " + fileType + " format not supported");
        }
    }
}
