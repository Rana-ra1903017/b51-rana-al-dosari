package adapter;

/** The interface that the client (AudioPlayer) expects. */
public interface MediaPlayer {
    void play(String fileType, String fileName);
}
