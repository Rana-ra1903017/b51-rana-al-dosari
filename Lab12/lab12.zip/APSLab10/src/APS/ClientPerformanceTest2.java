package APS;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;

import java.time.LocalDateTime;

import controller.BidResult;
import controller.BiddingController;
import model.AuctionSale;
import model.Bid;
import model.Client;
import model.IndividualClient;

/**
 * JMeter wrapper for the APS Client class (Task 4), adapted to the APSLab10 classes:
 * Client is abstract (IndividualClient), an item on auction is an AuctionSale,
 * and Bid has the constructor Bid(double amount, LocalDateTime placedAt).
 * Each sample creates a Client, an auction, places a Bid through UC006 and records it in the client.
 */
public class ClientPerformanceTest2 implements JavaSamplerClient {

    @Override
    public void setupTest(JavaSamplerContext context) {
        // Optional: initialize resources if needed
    }

    @Override
    public SampleResult runTest(JavaSamplerContext context) {
        SampleResult result = new SampleResult();
        result.sampleStart(); // Start timing

        try {
            // Create Client
            Client client = new IndividualClient(101, "Fatima", "Doha");
            LocalDateTime now = LocalDateTime.of(2025, 11, 18, 10, 0);

            // Create the item on auction (starting price QAR 400, ends in one day)
            AuctionSale auction = new AuctionSale(400.0, now.plusDays(1));

            // Create Bid through UC006 Place bid
            BiddingController bidding = new BiddingController();
            bidding.selectAuction(auction, now);
            BidResult outcome = bidding.placeBid(client, 500.0, now);

            // Record the bid in the client's registration
            Bid bid = auction.getBids().get(auction.getBids().size() - 1);
            client.addBid(bid);

            if (outcome != BidResult.ACCEPTED || client.getBids().size() != 1) {
                throw new IllegalStateException("Unexpected result: " + outcome);
            }

            // Success
            result.setSuccessful(true);
            result.setResponseMessage("Client operations executed successfully");
            result.setResponseCodeOK();

        } catch (Exception e) {
            result.setSuccessful(false);
            result.setResponseMessage("Error: " + e.getMessage());
            result.setResponseCode("500");
        } finally {
            result.sampleEnd(); // End timing
        }
        return result;
    }

    @Override
    public void teardownTest(JavaSamplerContext context) {
        // Optional: clean up resources if needed
    }

    @Override
    public Arguments getDefaultParameters() {
        return new Arguments();
    }
}
