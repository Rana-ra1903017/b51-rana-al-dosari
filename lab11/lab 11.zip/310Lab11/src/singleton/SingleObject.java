package singleton;

public class SingleObject {

    // create the only object of SingleObject
    private static SingleObject instance = new SingleObject();

    // private constructor: no other class can instantiate it
    private SingleObject() {
    }

    // get the only object available
    public static SingleObject getInstance() {
        return instance;
    }

    public void showMessage() {
        System.out.println("Hello World!");
    }
}
