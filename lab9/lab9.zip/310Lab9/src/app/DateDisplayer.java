package app;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class DateDisplayer extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        Pane root = FXMLLoader.load(getClass().getResource("/view/DateView.fxml"));
        stage.setScene(new Scene(root, 300, 100));
        stage.setTitle("Date Displayer App");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}