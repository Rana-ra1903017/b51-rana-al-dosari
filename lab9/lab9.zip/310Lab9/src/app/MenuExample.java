package app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MenuExample extends Application {
    @Override
    public void start(final Stage stage) throws Exception {
        Pane root = FXMLLoader.load(getClass().getResource("/view/Menu.fxml"));
        stage.setScene(new Scene(root, 600, 400));
        stage.setTitle("Welcome to All Phones Shop (APS)");
        stage.show();
    }

    public static void main(String[] arguments) {
        Application.launch(MenuExample.class, arguments);
    }
}