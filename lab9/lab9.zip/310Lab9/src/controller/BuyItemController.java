package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class BuyItemController {
    @FXML private TextField modelField;
    @FXML private TextField makeField;
    @FXML private TextField capacityField;
    @FXML private TextField colorField;
    @FXML private TextField quantityField;
    @FXML private Button enterButton;

    @FXML
    void enter(ActionEvent event) {
        if (modelField.getText().isEmpty() || makeField.getText().isEmpty()
                || capacityField.getText().isEmpty() || colorField.getText().isEmpty()
                || quantityField.getText().isEmpty()) {
            displayMessage("Please fill in all the fields.", AlertType.ERROR);
            return;
        }
        displayMessage("Buy order submitted:\n"
                + "Model: " + modelField.getText() + "\n"
                + "Make: " + makeField.getText() + "\n"
                + "Capacity: " + capacityField.getText() + "\n"
                + "Color: " + colorField.getText() + "\n"
                + "Quantity: " + quantityField.getText(),
                AlertType.INFORMATION);
        modelField.clear();
        makeField.clear();
        capacityField.clear();
        colorField.clear();
        quantityField.clear();
    }

    public void displayMessage(String message, AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("APS Message");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}