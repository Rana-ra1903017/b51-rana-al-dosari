package controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import model.DateModel;

public class DateController {
    private DateModel model = new DateModel();

    @FXML
    private Label dateView;

    @FXML
    private Button displayDateButton;

    @FXML
    void displayDate(ActionEvent event) {
        dateView.setText(model.getCurrentDate());
    }
}