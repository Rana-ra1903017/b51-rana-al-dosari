package controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.MenuBar;
import javafx.stage.Stage;

public class MenuController {
    @FXML
    private MenuBar menuBar;

    @FXML
    void buyOnAuction(ActionEvent event) {
        displayMessage("Buy on Auction is waiting to be implemented", AlertType.CONFIRMATION);
    }

    @FXML
    void buyOnFixed(ActionEvent event) {
        openForm("/view/BuyItemView.fxml", "Buy on Fixed Price");
    }

    @FXML
    void checkShoppingBasket(ActionEvent event) {
        displayMessage("Checking the shopping basket is waiting to be implemented", AlertType.CONFIRMATION);
    }

    @FXML
    void deleteClient(ActionEvent event) {
        displayMessage("Delete a client (by corporate clients only) is waiting\nto be implemented", AlertType.CONFIRMATION);
    }

    @FXML
    void exit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void findBill(ActionEvent event) {
        displayMessage("Finding a bill is waiting to be implemented", AlertType.CONFIRMATION);
    }

    @FXML
    void getReceipt(ActionEvent event) {
        displayMessage("Getting a receipt is waiting to be implemented", AlertType.CONFIRMATION);
    }

    @FXML
    void registerNewClient(ActionEvent event) {
        displayMessage("Registering a new client is waiting to be implemented", AlertType.CONFIRMATION);
    }

    @FXML
    void sellItem(ActionEvent event) {
        openForm("/view/SellItemView.fxml", "Sell Item");
    }

    // Opens a form (FXML file) in a new window
    private void openForm(String fxmlPath, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            displayMessage("Could not open the form: " + fxmlPath, AlertType.ERROR);
        }
    }

    public void displayMessage(String message, AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("APS Message");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}