package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class SellItemController {
    @FXML private TextField modelField;
    @FXML private TextField makeField;
    @FXML private TextField capacityField;
    @FXML private TextField colorField;
    @FXML private TextField priceField;
    @FXML private Button enterButton;

    @FXML
    void enter(ActionEvent event) {
        if (modelField.getText().isEmpty() || makeField.getText().isEmpty()
                || capacityField.getText().isEmpty() || colorField.getText().isEmpty()
                || priceField.getText().isEmpty()) {
            displayMessage("Please fill in all the fields.", AlertType.ERROR);
            return;
        }
        displayMessage("Item submitted for sale:\n"
                + "Model: " + modelField.getText() + "\n"
                + "Make: " + makeField.getText() + "\n"
                + "Capacity: " + capacityField.getText() + "\n"
                + "Color: " + colorField.getText() + "\n"
                + "Price: " + priceField.getText() + " QAR",
                AlertType.INFORMATION);
        modelField.clear();
        makeField.clear();
        capacityField.clear();
        colorField.clear();
        priceField.clear();
    }

    public void displayMessage(String message, AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("APS Message");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}